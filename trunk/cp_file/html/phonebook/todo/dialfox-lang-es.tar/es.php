<?
// SNOM MENU ////////////////////


$snom1="Directorio Local";
$snom2="Directorio Global";
$snom3="Buscar en el directorio telefonico";
$snom4="Buscar a";
$snom5="DIRECTORIO TELEFONICO SNOM";
$snom6="Lista de llamadas";

// reporet.php
$report_table1="Entrante";
$report_table2="Saliente";
$report_table3="Llamadas";
$report_table4="Fecha";
$report_table5="Hora";
$report_table6="Local";
$report_table7="de";
$report_table8="para";

// book.php
$book_1="No eliminar";

//new_number.php
$new_txt1="Numero de telefono";
$new_txt2="Nombre";
$new_txt3="Comentario";
$new_txt4="Agregar un nuevo numero telefonico";

// manager.php
$manager_from="DE";
$manager_to="PARA";
?>
